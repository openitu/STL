#!/bin/bash
/progra~1/Adobe/Acroba~1.0/Distillr/AcroDist 'd:\simao\STL\doc\stl2000\'$1
