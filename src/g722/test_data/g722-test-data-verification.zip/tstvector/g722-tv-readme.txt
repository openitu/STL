TEST VECTORS FOR ITU-T G.722
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Files in folders bigendian and littleendian contain the UGST binary
version of the G.722 test vectors.

Files in folder ascii are the original ASCII (HEX) representations and
need to be processed by asc2bin application in unsup folder.

The following table contains the CRC32 for the big and little endian
versions of the G.722 test vectors in binary format (STL - 16 bit/sample)

+------------+-----------+-------------+--------+
+ Test file  + Big end.  | Little end. +  Bytes +
+------------+-----------+-------------+--------+
| bt1c1.xmt  | 015ACCE4  | 0C3BFCA7    |  32832 | 
| bt1c2.xmt  | EAFC99B4  | 2D604685    |   1600 | 
| bt1d3.cod  | 1C85BE45  | 7398964F    |  32832 | 
| bt2r1.cod  | 0B904231  | D1DAA1D1    |  32832 | 
| bt2r2.cod  | F928980D  | 344EA5D0    |   1600 | 
| bt3h1.rc0  | 0BDE9C9C  | E9250851    |  32832 | 
| bt3h2.rc0  | 3A54C7DF  | 5330AE2E    |   1600 | 
| bt3h3.rc0  | 8E8DEE65  | 3731AD7F    |  32832 | 
| bt3l1.rc1  | 90DD2D72  | ED1B3993    |  32832 | 
| bt3l1.rc2  | FE7C4611  | 8E8C4E2B    |  32832 | 
| bt3l1.rc3  | 20B5FFC4  | B7AA5569    |  32832 | 
| bt3l2.rc1  | D2599DE8  | AF00F31F    |   1600 | 
| bt3l2.rc2  | 84041F43  | 9143E92C    |   1600 | 
| bt3l2.rc3  | F32628D9  | AE855C07    |   1600 | 
| bt3l3.rc1  | 8C12ED04  | A5374659    |  32832 | 
| bt3l3.rc2  | 550534A7  | 687B250A    |  32832 | 
| bt3l3.rc3  | 9354E9CF  | 3605736B    |  32832 | 
| codsp.cod  | E241B6B9  | 23D6CE75    |  48768 | 
| codspw.cod | 0F126150  | 4D0F0E22    |  97536 | 
| inpsp.bin  | F92ED03D  | C9BACC0B    | 195072 | 
| outsp1.bin | C682330C  | 28E883BA    | 195072 | 
| outsp2.bin | 63BC8916  | 5EFEEB04    | 195072 | 
| outsp3.bin | 5F2D3C6A  | 57533121    | 195072 | 
+------------+-----------+-------------+--------+

-- Simao - 2017.03.24
