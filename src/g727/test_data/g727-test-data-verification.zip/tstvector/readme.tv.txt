G.727 Test vectors
~~~~~~~~~~~~~~~~~~

The test vectors in this zip file are files in the UGST format, with 16-bit words
holding 5,4,3, or 2 valid bits. Folder bigendian contains the files as needed for big endian ("Unix format") 
platforms. The directory littleendian has the same files (same names) as in, but 
byte-swaped to little endian format (PC format), which is also used by 
VMS and Alpha CPUs.

Use them according to the byte orientation in your computer.

Directory _general contains the original readme files for the G.727 test 
vectors.

Simao.
--
